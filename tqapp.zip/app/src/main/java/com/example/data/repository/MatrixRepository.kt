package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.CallEntity
import com.example.data.local.ContactEntity
import com.example.data.local.MessageEntity
import com.example.data.local.RoomEntity
import com.example.data.local.StoryEntity
import com.example.data.local.UserSessionEntity
import com.example.data.matrix.MatrixApiClient
import com.example.data.matrix.MatrixServersConfig
import com.example.data.matrix.models.CreateRoomRequest
import com.example.data.matrix.models.LoginRequest
import com.example.data.matrix.models.RegisterAuth
import com.example.data.matrix.models.RegisterRequest
import com.example.data.matrix.models.SendMessageRequest
import com.example.data.matrix.models.TokenLoginRequest
import com.example.data.matrix.models.UserIdentifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.UUID

sealed class AuthResult {
    data class Success(val userId: String, val serverUrl: String) : AuthResult()
    data class Error(val message: String) : AuthResult()
    data class RequiresRecaptcha(
        val session: String,
        val publicKey: String,
        val serverUrl: String,
        val username: String,
        val password: String
    ) : AuthResult()
}

class MatrixRepository(
    private val database: AppDatabase
) {
    val sessionFlow: Flow<UserSessionEntity?> = database.userSessionDao().getSessionFlow()
    val roomsFlow: Flow<List<RoomEntity>> = database.roomDao().getChatsAndGroups()
    val invitesFlow: Flow<List<RoomEntity>> = database.roomDao().getInvites()
    val allRoomsFlow: Flow<List<RoomEntity>> = database.roomDao().getAllRooms()
    val channelsFlow: Flow<List<RoomEntity>> = database.roomDao().getChannels()
    val communitiesFlow: Flow<List<RoomEntity>> = database.roomDao().getCommunities()
    val contactsFlow: Flow<List<ContactEntity>> = database.contactDao().getAllContacts()
    val activeStoriesFlow: Flow<List<StoryEntity>> = database.storyDao().getActiveStories()
    val myStoriesFlow: Flow<List<StoryEntity>> = database.storyDao().getMyActiveStories()
    val callsFlow: Flow<List<CallEntity>> = database.callDao().getAllCalls()

    private var syncBatchToken: String? = null
    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    fun getMessagesForRoom(roomId: String): Flow<List<MessageEntity>> =
        database.messageDao().getMessagesForRoom(roomId)

    fun getRoom(roomId: String): Flow<RoomEntity?> =
        database.roomDao().getRoomById(roomId)

    suspend fun getCurrentSession(): UserSessionEntity? = withContext(Dispatchers.IO) {
        database.userSessionDao().getSession()
    }

    suspend fun loginWithMatrix(serverUrl: String, usernameInput: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        val cleanUrl = MatrixServersConfig.cleanUrl(serverUrl)
        val cleanUser = usernameInput.trim()

        try {
            val api = MatrixApiClient.getService(cleanUrl)
            val request = LoginRequest(
                identifier = UserIdentifier(user = cleanUser),
                password = password
            )
            val response = api.login(request)
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                val session = UserSessionEntity(
                    userId = body.userId,
                    homeserverUrl = cleanUrl,
                    accessToken = body.accessToken,
                    deviceId = body.deviceId,
                    displayName = cleanUser.removePrefix("@").substringBefore(":"),
                    isLoggedIn = true,
                    isDemoMode = false
                )
                database.deleteMockData()
                database.userSessionDao().insertSession(session)
                syncWithMatrix(timeout = 0)
                AuthResult.Success(body.userId, cleanUrl)
            } else {
                val errorBody = response.errorBody()?.string() ?: ""
                AuthResult.Error(
                    if (errorBody.contains("M_FORBIDDEN") || response.code() == 403) {
                        "Usuario o contraseña incorrectos en $cleanUrl"
                    } else if (response.code() == 404) {
                        "El servidor no parece admitir la API de Matrix en $cleanUrl"
                    } else {
                        "Error al iniciar sesión (${response.code()}): $errorBody"
                    }
                )
            }
        } catch (e: Exception) {
            AuthResult.Error("No se pudo conectar con el servidor Matrix ($cleanUrl): ${e.localizedMessage ?: "Error de red"}")
        }
    }

    suspend fun loginWithMatrixToken(serverUrl: String, token: String): AuthResult = withContext(Dispatchers.IO) {
        val cleanUrl = MatrixServersConfig.cleanUrl(serverUrl)
        try {
            val api = MatrixApiClient.getService(cleanUrl)
            val request = TokenLoginRequest(token = token.trim())
            val response = api.loginWithToken(request)
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                val cleanUser = body.userId.removePrefix("@").substringBefore(":")
                val session = UserSessionEntity(
                    userId = body.userId,
                    homeserverUrl = cleanUrl,
                    accessToken = body.accessToken,
                    deviceId = body.deviceId,
                    displayName = cleanUser,
                    isLoggedIn = true,
                    isDemoMode = false
                )
                database.deleteMockData()
                database.userSessionDao().insertSession(session)
                syncWithMatrix(timeout = 0)
                AuthResult.Success(body.userId, cleanUrl)
            } else {
                val errorBody = response.errorBody()?.string() ?: ""
                val msg = try {
                    JSONObject(errorBody).optString("error", "Token de autenticación SSO inválido o expirado")
                } catch (_: Exception) {
                    "Error al validar token de autenticación ($cleanUrl: ${response.code()})"
                }
                AuthResult.Error(msg)
            }
        } catch (e: Exception) {
            AuthResult.Error("Error al conectar con servidor Matrix para validar token: ${e.localizedMessage ?: "Error de red"}")
        }
    }

    suspend fun registerWithMatrix(serverUrl: String, usernameInput: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        val cleanUrl = MatrixServersConfig.cleanUrl(serverUrl)
        // Extract localpart if user entered @user:domain or just user
        val cleanUser = usernameInput.trim().removePrefix("@").substringBefore(":").lowercase()

        try {
            val api = MatrixApiClient.getService(cleanUrl)
            // Initial registration request without auth to discover flows or register directly
            val request = RegisterRequest(
                username = cleanUser,
                password = password,
                auth = null
            )
            val response = api.register(request)
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                val session = UserSessionEntity(
                    userId = body.userId,
                    homeserverUrl = cleanUrl,
                    accessToken = body.accessToken,
                    deviceId = body.deviceId,
                    displayName = cleanUser,
                    isLoggedIn = true,
                    isDemoMode = false
                )
                database.deleteMockData()
                database.userSessionDao().insertSession(session)
                syncWithMatrix(timeout = 0)
                return@withContext AuthResult.Success(body.userId, cleanUrl)
            }

            val errorBody = response.errorBody()?.string() ?: ""
            val json = try { JSONObject(errorBody) } catch (_: Exception) { null }

            // If 401 Unauthorized, Matrix is returning UIA (User-Interactive Authentication)
            if (response.code() == 401 && json != null) {
                val session = json.optString("session", "")
                val flows = json.optJSONArray("flows")
                val params = json.optJSONObject("params")

                // 1. Check if dummy auth is sufficient
                var hasDummyOnly = false
                if (flows != null) {
                    for (i in 0 until flows.length()) {
                        val flow = flows.optJSONObject(i)
                        val stages = flow?.optJSONArray("stages")
                        if (stages != null && stages.length() == 1 && stages.optString(0) == "m.login.dummy") {
                            hasDummyOnly = true
                            break
                        }
                    }
                }

                if (hasDummyOnly && session.isNotBlank()) {
                    // Automatically complete registration using dummy auth stage
                    val dummyRequest = RegisterRequest(
                        username = cleanUser,
                        password = password,
                        auth = RegisterAuth(type = "m.login.dummy", session = session)
                    )
                    val dummyResp = api.register(dummyRequest)
                    if (dummyResp.isSuccessful && dummyResp.body() != null) {
                        val body = dummyResp.body()!!
                        val sessionEntity = UserSessionEntity(
                            userId = body.userId,
                            homeserverUrl = cleanUrl,
                            accessToken = body.accessToken,
                            deviceId = body.deviceId,
                            displayName = cleanUser,
                            isLoggedIn = true,
                            isDemoMode = false
                        )
                        database.deleteMockData()
                        database.userSessionDao().insertSession(sessionEntity)
                        syncWithMatrix(timeout = 0)
                        return@withContext AuthResult.Success(body.userId, cleanUrl)
                    }
                }

                // 2. Check if reCAPTCHA is required (matrix.org and major servers)
                val recaptchaParams = params?.optJSONObject("m.login.recaptcha")
                var requiresRecaptcha = recaptchaParams != null
                if (flows != null) {
                    for (i in 0 until flows.length()) {
                        val flow = flows.optJSONObject(i)
                        val stages = flow?.optJSONArray("stages")
                        if (stages != null) {
                            for (j in 0 until stages.length()) {
                                if (stages.optString(j) == "m.login.recaptcha") {
                                    requiresRecaptcha = true
                                    break
                                }
                            }
                        }
                    }
                }

                if (requiresRecaptcha) {
                    val publicKey = recaptchaParams?.optString("public_key")
                        ?.takeIf { it.isNotBlank() }
                        ?: "6LdXkhsUAAAAAAvE_534ZkK-96q611eH_sY1Fh" // Standard Matrix.org reCAPTCHA v2 key

                    return@withContext AuthResult.RequiresRecaptcha(
                        session = session,
                        publicKey = publicKey,
                        serverUrl = cleanUrl,
                        username = cleanUser,
                        password = password
                    )
                }
            }

            // Specific error handling
            val errCode = json?.optString("errcode") ?: ""
            val errMessage = json?.optString("error") ?: ""

            AuthResult.Error(
                when {
                    errCode == "M_USER_IN_USE" || errorBody.contains("M_USER_IN_USE") -> {
                        "El usuario '@$cleanUser' ya existe en $cleanUrl. Ve a la pestaña 'INICIAR SESIÓN' para ingresar con tu contraseña."
                    }
                    errCode == "M_EXCLUSIVE" || errorBody.contains("M_EXCLUSIVE") -> {
                        "El nombre de usuario '@$cleanUser' no está disponible o está reservado."
                    }
                    errCode == "M_FORBIDDEN" || errorBody.contains("registration has been disabled") || errorBody.contains("m.login.application_service") || response.code() == 403 -> {
                        "El servidor $cleanUrl ha deshabilitado el registro directo por API abierta (requiere verificación web oficial). Puedes crear tu cuenta real en https://app.element.io/#/register y luego pulsar 'INICIAR SESIÓN' aquí."
                    }
                    errMessage.isNotBlank() -> {
                        "El servidor respondió: $errMessage"
                    }
                    else -> {
                        "Error del servidor Matrix ($cleanUrl, código ${response.code()})."
                    }
                }
            )
        } catch (e: Exception) {
            AuthResult.Error("No se pudo conectar para registrar en $cleanUrl: ${e.localizedMessage ?: "Error de red"}")
        }
    }

    suspend fun completeRecaptchaRegistration(
        serverUrl: String,
        username: String,
        password: String,
        session: String,
        recaptchaToken: String
    ): AuthResult = withContext(Dispatchers.IO) {
        val cleanUrl = MatrixServersConfig.cleanUrl(serverUrl)
        try {
            val api = MatrixApiClient.getService(cleanUrl)
            val request = RegisterRequest(
                username = username,
                password = password,
                auth = RegisterAuth(
                    type = "m.login.recaptcha",
                    session = session,
                    response = recaptchaToken
                )
            )
            val response = api.register(request)
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                val sessionEntity = UserSessionEntity(
                    userId = body.userId,
                    homeserverUrl = cleanUrl,
                    accessToken = body.accessToken,
                    deviceId = body.deviceId,
                    displayName = username,
                    isLoggedIn = true,
                    isDemoMode = false
                )
                database.deleteMockData()
                database.userSessionDao().insertSession(sessionEntity)
                syncWithMatrix(timeout = 0)
                AuthResult.Success(body.userId, cleanUrl)
            } else {
                val errorBody = response.errorBody()?.string() ?: ""
                val json = try { JSONObject(errorBody) } catch (_: Exception) { null }
                val errorMsg = json?.optString("error") ?: "Error al validar el CAPTCHA con el servidor Matrix."
                AuthResult.Error(errorMsg)
            }
        } catch (e: Exception) {
            AuthResult.Error("Fallo al enviar respuesta del CAPTCHA: ${e.localizedMessage ?: "Error de conexión"}")
        }
    }

    suspend fun loginAsQuickDemo(chosenServerUrl: String, username: String = "usuario_matrix") = withContext(Dispatchers.IO) {
        val cleanUrl = MatrixServersConfig.cleanUrl(chosenServerUrl)
        val cleanUser = if (username.startsWith("@")) username else "@$username:${cleanUrl.removePrefix("https://").removePrefix("http://")}"
        val session = UserSessionEntity(
            userId = cleanUser,
            homeserverUrl = cleanUrl,
            accessToken = "demo_token_" + UUID.randomUUID().toString().take(8),
            displayName = username.removePrefix("@").substringBefore(":"),
            isLoggedIn = true,
            isDemoMode = true
        )
        database.userSessionDao().insertSession(session)
        database.prepopulateInitialData()
    }

    suspend fun logout() = withContext(Dispatchers.IO) {
        syncBatchToken = null
        database.userSessionDao().clearSession()
        database.clearAllData()
    }

    suspend fun sendMessage(roomId: String, text: String): Boolean = withContext(Dispatchers.IO) {
        if (text.isBlank()) return@withContext false
        val session = database.userSessionDao().getSession()
        val now = System.currentTimeMillis()
        val messageId = "msg_" + UUID.randomUUID().toString()

        val localMessage = MessageEntity(
            id = messageId,
            roomId = roomId,
            senderId = session?.userId ?: "@me",
            senderName = session?.displayName ?: "Yo",
            content = text.trim(),
            timestamp = now,
            status = "SENT",
            isOutgoing = true,
            messageType = "TEXT"
        )
        database.messageDao().insertMessage(localMessage)
        database.roomDao().updateLastMessage(roomId, text.trim(), now)

        // If connected to live Matrix server (not offline demo), send over Matrix API
        if (session != null && !session.isDemoMode && session.accessToken.isNotBlank()) {
            try {
                val api = MatrixApiClient.getService(session.homeserverUrl)
                val txnId = "txn_" + System.currentTimeMillis()
                val resp = api.sendMessage(
                    authHeader = "Bearer ${session.accessToken}",
                    roomId = roomId,
                    txnId = txnId,
                    request = SendMessageRequest(body = text.trim())
                )
                if (resp.isSuccessful) {
                    database.messageDao().updateMessageStatus(messageId, "DELIVERED")
                }
            } catch (_: Exception) {
                // Keep local message intact
            }
        }
        true
    }

    suspend fun createRoom(
        name: String,
        topic: String = "",
        roomType: String = "GROUP",
        isDirect: Boolean = false,
        inviteUserId: String? = null,
        parentSpaceId: String? = null
    ): String = withContext(Dispatchers.IO) {
        val session = database.userSessionDao().getSession()
        val generatedId = "!room_" + UUID.randomUUID().toString().take(10) + ":" +
                (session?.homeserverUrl?.removePrefix("https://")?.removePrefix("http://") ?: "matrix.org")

        var finalRoomId = generatedId
        if (session != null && !session.isDemoMode && session.accessToken.isNotBlank()) {
            try {
                val api = MatrixApiClient.getService(session.homeserverUrl)
                val invites = if (inviteUserId != null) listOf(inviteUserId) else emptyList()
                val resp = api.createRoom(
                    authHeader = "Bearer ${session.accessToken}",
                    request = CreateRoomRequest(
                        name = name,
                        topic = topic,
                        preset = if (roomType == "CHANNEL") "public_chat" else "private_chat",
                        isDirect = isDirect,
                        invite = invites
                    )
                )
                if (resp.isSuccessful && resp.body() != null) {
                    finalRoomId = resp.body()!!.roomId
                }
            } catch (_: Exception) {
                // Fallback to generated ID
            }
        }

        val room = RoomEntity(
            roomId = finalRoomId,
            name = name,
            topic = topic,
            roomType = roomType,
            lastMessage = "Sala creada",
            lastTimestamp = System.currentTimeMillis(),
            unreadCount = 0,
            parentSpaceId = parentSpaceId,
            directUserId = inviteUserId
        )
        database.roomDao().insertRoom(room)

        val firstMessage = MessageEntity(
            id = "sys_" + UUID.randomUUID().toString(),
            roomId = finalRoomId,
            senderId = session?.userId ?: "@me",
            senderName = "Sistema",
            content = if (roomType == "COMMUNITY") "Comunidad creada" else "Mensajes cifrados de extremo a extremo con Matrix",
            timestamp = System.currentTimeMillis(),
            status = "READ",
            isOutgoing = false,
            messageType = "SYSTEM"
        )
        database.messageDao().insertMessage(firstMessage)

        finalRoomId
    }

    suspend fun postStory(
        text: String,
        backgroundColorHex: String = "#075E54"
    ) = withContext(Dispatchers.IO) {
        val session = database.userSessionDao().getSession()
        val now = System.currentTimeMillis()
        val story = StoryEntity(
            id = "story_" + UUID.randomUUID().toString(),
            userId = session?.userId ?: "@me",
            userName = session?.displayName ?: "Mi estado",
            content = text.trim(),
            backgroundColorHex = backgroundColorHex,
            timestamp = now,
            expiresAt = now + 86400000L, // 24 hours
            isViewed = false,
            viewsCount = 0,
            isMine = true
        )
        database.storyDao().insertStory(story)
    }

    suspend fun markStoryViewed(storyId: String) = withContext(Dispatchers.IO) {
        database.storyDao().markStoryViewed(storyId)
    }

    suspend fun markRoomAsRead(roomId: String) = withContext(Dispatchers.IO) {
        database.roomDao().markRoomAsRead(roomId)
    }

    suspend fun registerCall(contactName: String, callType: String, direction: String = "OUTGOING", duration: Int = 0) = withContext(Dispatchers.IO) {
        val call = CallEntity(
            contactName = contactName,
            callType = callType,
            direction = direction,
            timestamp = System.currentTimeMillis(),
            durationSeconds = duration
        )
        database.callDao().insertCall(call)
    }

    suspend fun addContact(userId: String, displayName: String) = withContext(Dispatchers.IO) {
        val contact = ContactEntity(
            userId = userId.trim(),
            displayName = displayName.trim(),
            statusMessage = "Conectado a la federación Matrix",
            lastSeen = "reciente"
        )
        database.contactDao().insertContact(contact)
    }

    suspend fun syncWithMatrix(timeout: Long = 0): Boolean = withContext(Dispatchers.IO) {
        val session = database.userSessionDao().getSession() ?: return@withContext false
        if (session.isDemoMode || session.accessToken.isBlank()) return@withContext false

        // Purge any lingering demo/mock items
        database.deleteMockData()

        _isSyncing.value = true
        try {
            val api = MatrixApiClient.getService(session.homeserverUrl)
            val authHeader = "Bearer ${session.accessToken}"

            // 1. Fetch user's real profile
            try {
                val profileResp = api.getProfile(session.userId)
                if (profileResp.isSuccessful && profileResp.body() != null) {
                    val p = profileResp.body()!!
                    val realDisplayName = p.displayName ?: session.displayName
                    if (realDisplayName != session.displayName || p.avatarUrl != session.avatarUrl) {
                        database.userSessionDao().insertSession(
                            session.copy(displayName = realDisplayName, avatarUrl = p.avatarUrl)
                        )
                    }
                }
            } catch (_: Exception) {}

            // 2. Call /_matrix/client/v3/sync
            val syncResp = api.sync(
                authHeader = authHeader,
                since = syncBatchToken,
                timeout = timeout
            )

            if (!syncResp.isSuccessful || syncResp.body() == null) {
                _isSyncing.value = false
                return@withContext false
            }

            val bodyString = syncResp.body()!!.string()
            val syncJson = JSONObject(bodyString)

            syncBatchToken = syncJson.optString("next_batch", null)

            val roomsObj = syncJson.optJSONObject("rooms")
            val joinObj = roomsObj?.optJSONObject("join")

            if (joinObj != null) {
                val roomKeys = joinObj.keys()
                val roomsToInsert = mutableListOf<RoomEntity>()
                val messagesToInsert = mutableListOf<MessageEntity>()
                val contactsToInsert = mutableListOf<ContactEntity>()

                while (roomKeys.hasNext()) {
                    val roomId = roomKeys.next()
                    val roomData = joinObj.getJSONObject(roomId)

                    var roomName: String? = null
                    var roomTopic = ""
                    var roomAvatarUrl: String? = null
                    var canonicalAlias: String? = null
                    var isDirect = false
                    var directUserId: String? = null
                    var isCommunity = false
                    val memberNames = mutableMapOf<String, String>()

                    // Extract state events
                    val stateEvents = roomData.optJSONObject("state")?.optJSONArray("events")
                    if (stateEvents != null) {
                        for (i in 0 until stateEvents.length()) {
                            val evt = stateEvents.optJSONObject(i) ?: continue
                            val type = evt.optString("type")
                            val content = evt.optJSONObject("content") ?: continue
                            when (type) {
                                "m.room.name" -> {
                                    val n = content.optString("name")
                                    if (n.isNotBlank()) roomName = n
                                }
                                "m.room.topic" -> {
                                    roomTopic = content.optString("topic", "")
                                }
                                "m.room.canonical_alias" -> {
                                    val alias = content.optString("alias")
                                    if (alias.isNotBlank()) canonicalAlias = alias
                                }
                                "m.room.avatar" -> {
                                    roomAvatarUrl = content.optString("url")
                                }
                                "m.room.create" -> {
                                    if (content.optString("type") == "m.space") isCommunity = true
                                }
                                "m.space.child" -> {
                                    isCommunity = true
                                }
                                "m.room.member" -> {
                                    val stateKey = evt.optString("state_key")
                                    val dName = content.optString("displayname")
                                    if (stateKey.isNotBlank() && dName.isNotBlank()) {
                                        memberNames[stateKey] = dName
                                    }
                                }
                            }
                        }
                    }

                    // Extract timeline events
                    val timeline = roomData.optJSONObject("timeline")
                    val timelineEvents = timeline?.optJSONArray("events")
                    var latestMessageText: String? = null
                    var latestTimestamp = System.currentTimeMillis()

                    if (timelineEvents != null) {
                        for (i in 0 until timelineEvents.length()) {
                            val evt = timelineEvents.optJSONObject(i) ?: continue
                            val type = evt.optString("type")
                            val content = evt.optJSONObject("content") ?: continue

                            when (type) {
                                "m.room.name" -> {
                                    val n = content.optString("name")
                                    if (n.isNotBlank()) roomName = n
                                }
                                "m.room.topic" -> {
                                    roomTopic = content.optString("topic", "")
                                }
                                "m.room.canonical_alias" -> {
                                    val alias = content.optString("alias")
                                    if (alias.isNotBlank()) canonicalAlias = alias
                                }
                                "m.room.member" -> {
                                    val stateKey = evt.optString("state_key")
                                    val dName = content.optString("displayname")
                                    if (stateKey.isNotBlank() && dName.isNotBlank()) {
                                        memberNames[stateKey] = dName
                                    }
                                }
                                "m.room.message" -> {
                                    val sender = evt.optString("sender")
                                    val ts = evt.optLong("origin_server_ts", System.currentTimeMillis())
                                    val eventId = evt.optString("event_id", "evt_${System.currentTimeMillis()}_$i")
                                    val body = content.optString("body", "")
                                    val msgType = content.optString("msgtype", "m.text")

                                    latestMessageText = body
                                    latestTimestamp = ts

                                    val senderDisplayName = memberNames[sender]
                                        ?: (if (sender == session.userId) "Yo" else sender.removePrefix("@").substringBefore(":"))

                                    messagesToInsert.add(
                                        MessageEntity(
                                            id = eventId,
                                            roomId = roomId,
                                            senderId = sender,
                                            senderName = senderDisplayName,
                                            content = body,
                                            timestamp = ts,
                                            status = "READ",
                                            isOutgoing = (sender == session.userId),
                                            messageType = when (msgType) {
                                                "m.image" -> "IMAGE"
                                                "m.audio" -> "AUDIO"
                                                "m.video" -> "VIDEO"
                                                else -> "TEXT"
                                            }
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Extract summary heroes if room name is not set
                    val summary = roomData.optJSONObject("summary")
                    val heroes = summary?.optJSONArray("m.heroes")
                    if (heroes != null && heroes.length() > 0) {
                        val firstHero = heroes.optString(0)
                        if (firstHero.isNotBlank() && firstHero != session.userId) {
                            directUserId = firstHero
                            if (roomName.isNullOrBlank()) {
                                roomName = memberNames[firstHero] ?: firstHero.removePrefix("@").substringBefore(":")
                                isDirect = true
                            }
                        }
                    }

                    if (roomName.isNullOrBlank()) {
                        roomName = canonicalAlias ?: "Sala Matrix ${roomId.take(8)}"
                    }

                    val unread = roomData.optJSONObject("unread_notifications")?.optInt("notification_count", 0) ?: 0

                    val finalRoomType = when {
                        isCommunity -> "COMMUNITY"
                        isDirect -> "DIRECT"
                        else -> "GROUP"
                    }

                    roomsToInsert.add(
                        RoomEntity(
                            roomId = roomId,
                            name = roomName,
                            topic = roomTopic,
                            roomType = finalRoomType,
                            avatarUrl = roomAvatarUrl,
                            lastMessage = latestMessageText ?: "Sala conectada",
                            lastTimestamp = latestTimestamp,
                            unreadCount = unread,
                            directUserId = directUserId
                        )
                    )

                    // Add to contacts if direct chat
                    if (directUserId != null && directUserId != session.userId) {
                        val contactName = memberNames[directUserId] ?: directUserId.removePrefix("@").substringBefore(":")
                        contactsToInsert.add(
                            ContactEntity(
                                userId = directUserId,
                                displayName = contactName,
                                avatarUrl = null,
                                statusMessage = "Contacto en Matrix",
                                lastSeen = "en línea"
                            )
                        )
                    }
                }

                if (roomsToInsert.isNotEmpty()) {
                    database.roomDao().insertRooms(roomsToInsert)
                }
                if (messagesToInsert.isNotEmpty()) {
                    database.messageDao().insertMessages(messagesToInsert)
                }
                if (contactsToInsert.isNotEmpty()) {
                    database.contactDao().insertContacts(contactsToInsert)
                }
            }

            // Process invites
            val inviteObj = roomsObj?.optJSONObject("invite")
            if (inviteObj != null) {
                val inviteKeys = inviteObj.keys()
                val inviteRooms = mutableListOf<RoomEntity>()
                while (inviteKeys.hasNext()) {
                    val roomId = inviteKeys.next()
                    val inviteData = inviteObj.getJSONObject(roomId)
                    var inviteRoomName: String? = null
                    var inviterName: String? = null
                    val inviteState = inviteData.optJSONObject("invite_state")?.optJSONArray("events")
                    if (inviteState != null) {
                        for (i in 0 until inviteState.length()) {
                            val evt = inviteState.optJSONObject(i) ?: continue
                            val type = evt.optString("type")
                            val content = evt.optJSONObject("content") ?: continue
                            when (type) {
                                "m.room.name" -> {
                                    val n = content.optString("name")
                                    if (n.isNotBlank()) inviteRoomName = n
                                }
                                "m.room.member" -> {
                                    if (evt.optString("state_key") == session.userId) {
                                        val sender = evt.optString("sender")
                                        inviterName = sender.removePrefix("@").substringBefore(":")
                                    }
                                }
                            }
                        }
                    }
                    val display = inviteRoomName ?: (if (inviterName != null) "Invitación de $inviterName" else "Invitación a sala")
                    inviteRooms.add(
                        RoomEntity(
                            roomId = roomId,
                            name = display,
                            topic = "Invitación pendiente de Matrix",
                            roomType = "INVITE",
                            lastMessage = "Has sido invitado a unirte a esta conversación",
                            lastTimestamp = System.currentTimeMillis(),
                            unreadCount = 1
                        )
                    )
                }
                if (inviteRooms.isNotEmpty()) {
                    database.roomDao().insertRooms(inviteRooms)
                }
            }

            // Fallback: If rooms list is empty, query /joined_rooms directly
            try {
                val existingRooms = database.roomDao().getAllRooms()
                val joinedResp = api.getJoinedRooms(authHeader)
                if (joinedResp.isSuccessful && joinedResp.body() != null) {
                    val jObj = JSONObject(joinedResp.body()!!.string())
                    val jRooms = jObj.optJSONArray("joined_rooms")
                    if (jRooms != null && jRooms.length() > 0) {
                        val fallbackRooms = mutableListOf<RoomEntity>()
                        for (i in 0 until jRooms.length()) {
                            val rId = jRooms.getString(i)
                            // Query basic state for room if possible
                            var fetchedName: String? = null
                            try {
                                val stateResp = api.getRoomState(authHeader, rId)
                                if (stateResp.isSuccessful && stateResp.body() != null) {
                                    val stateArr = org.json.JSONArray(stateResp.body()!!.string())
                                    for (k in 0 until stateArr.length()) {
                                        val sEvt = stateArr.optJSONObject(k) ?: continue
                                        if (sEvt.optString("type") == "m.room.name") {
                                            fetchedName = sEvt.optJSONObject("content")?.optString("name")
                                        }
                                    }
                                }
                            } catch (_: Exception) {}

                            fallbackRooms.add(
                                RoomEntity(
                                    roomId = rId,
                                    name = fetchedName ?: "Sala ${rId.take(12)}",
                                    topic = "Conversación Matrix sincronizada",
                                    roomType = "GROUP",
                                    lastMessage = "Conectado a Matrix",
                                    lastTimestamp = System.currentTimeMillis()
                                )
                            )
                        }
                        if (fallbackRooms.isNotEmpty()) {
                            database.roomDao().insertRooms(fallbackRooms)
                        }
                    }
                }
            } catch (_: Exception) {}

            _isSyncing.value = false
            true
        } catch (e: Exception) {
            _isSyncing.value = false
            false
        }
    }

    suspend fun acceptInvite(roomId: String): Boolean = withContext(Dispatchers.IO) {
        val session = database.userSessionDao().getSession() ?: return@withContext false
        try {
            val api = MatrixApiClient.getService(session.homeserverUrl)
            val resp = api.joinRoom("Bearer ${session.accessToken}", roomId)
            if (resp.isSuccessful) {
                database.roomDao().deleteRoom(roomId)
                syncWithMatrix(timeout = 0)
                fetchRoomHistory(roomId)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    suspend fun rejectInvite(roomId: String): Boolean = withContext(Dispatchers.IO) {
        val session = database.userSessionDao().getSession() ?: return@withContext false
        try {
            val api = MatrixApiClient.getService(session.homeserverUrl)
            val resp = api.leaveRoom("Bearer ${session.accessToken}", roomId)
            if (resp.isSuccessful) {
                database.roomDao().deleteRoom(roomId)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    suspend fun acceptAllInvites(): Int = withContext(Dispatchers.IO) {
        val session = database.userSessionDao().getSession() ?: return@withContext 0
        var accepted = 0
        try {
            val api = MatrixApiClient.getService(session.homeserverUrl)
            // Fetch invites via sync or database
            val syncResp = api.sync(authHeader = "Bearer ${session.accessToken}", since = null, timeout = 0)
            if (syncResp.isSuccessful && syncResp.body() != null) {
                val syncJson = JSONObject(syncResp.body()!!.string())
                val invites = syncJson.optJSONObject("rooms")?.optJSONObject("invite")
                if (invites != null) {
                    val keys = invites.keys()
                    while (keys.hasNext()) {
                        val roomId = keys.next()
                        val joinResp = api.joinRoom("Bearer ${session.accessToken}", roomId)
                        if (joinResp.isSuccessful) {
                            database.roomDao().deleteRoom(roomId)
                            accepted++
                        }
                    }
                }
            }
            if (accepted > 0) {
                syncWithMatrix(timeout = 0)
            }
        } catch (_: Exception) {}
        accepted
    }

    suspend fun fetchRoomHistory(roomId: String) = withContext(Dispatchers.IO) {
        val session = database.userSessionDao().getSession() ?: return@withContext
        if (session.isDemoMode || session.accessToken.isBlank()) return@withContext

        try {
            val api = MatrixApiClient.getService(session.homeserverUrl)
            val authHeader = "Bearer ${session.accessToken}"
            val resp = api.getRoomMessages(
                authHeader = authHeader,
                roomId = roomId,
                dir = "b",
                limit = 50
            )
            if (resp.isSuccessful && resp.body() != null) {
                val json = JSONObject(resp.body()!!.string())
                val chunk = json.optJSONArray("chunk")
                if (chunk != null) {
                    val messages = mutableListOf<MessageEntity>()
                    for (i in 0 until chunk.length()) {
                        val evt = chunk.optJSONObject(i) ?: continue
                        if (evt.optString("type") != "m.room.message") continue
                        val content = evt.optJSONObject("content") ?: continue
                        val body = content.optString("body", "")
                        if (body.isBlank()) continue
                        val sender = evt.optString("sender")
                        val ts = evt.optLong("origin_server_ts", System.currentTimeMillis())
                        val eventId = evt.optString("event_id", "evt_${System.currentTimeMillis()}_$i")
                        val msgType = content.optString("msgtype", "m.text")

                        messages.add(
                            MessageEntity(
                                id = eventId,
                                roomId = roomId,
                                senderId = sender,
                                senderName = if (sender == session.userId) "Yo" else sender.removePrefix("@").substringBefore(":"),
                                content = body,
                                timestamp = ts,
                                status = "READ",
                                isOutgoing = (sender == session.userId),
                                messageType = when (msgType) {
                                    "m.image" -> "IMAGE"
                                    "m.audio" -> "AUDIO"
                                    "m.video" -> "VIDEO"
                                    else -> "TEXT"
                                }
                            )
                        )
                    }
                    if (messages.isNotEmpty()) {
                        database.messageDao().insertMessages(messages)
                    }
                }
            }
        } catch (_: Exception) {}
    }

    suspend fun updateDisplayName(newDisplayName: String): Boolean = withContext(Dispatchers.IO) {
        val session = database.userSessionDao().getSession() ?: return@withContext false
        try {
            if (!session.isDemoMode && session.accessToken.isNotBlank()) {
                val api = MatrixApiClient.getService(session.homeserverUrl)
                val resp = api.setDisplayName(
                    authHeader = "Bearer ${session.accessToken}",
                    userId = session.userId,
                    body = mapOf("displayname" to newDisplayName)
                )
                if (!resp.isSuccessful) return@withContext false
            }
            database.userSessionDao().insertSession(session.copy(displayName = newDisplayName))
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun updateAvatarUrl(newAvatarUrl: String): Boolean = withContext(Dispatchers.IO) {
        val session = database.userSessionDao().getSession() ?: return@withContext false
        try {
            if (!session.isDemoMode && session.accessToken.isNotBlank()) {
                val api = MatrixApiClient.getService(session.homeserverUrl)
                val resp = api.setAvatarUrl(
                    authHeader = "Bearer ${session.accessToken}",
                    userId = session.userId,
                    body = mapOf("avatar_url" to newAvatarUrl)
                )
                if (!resp.isSuccessful) return@withContext false
            }
            database.userSessionDao().insertSession(session.copy(avatarUrl = newAvatarUrl))
            true
        } catch (e: Exception) {
            false
        }
    }
}
