package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UserSessionDao {
    @Query("SELECT * FROM user_sessions WHERE id = 1 LIMIT 1")
    fun getSessionFlow(): Flow<UserSessionEntity?>

    @Query("SELECT * FROM user_sessions WHERE id = 1 LIMIT 1")
    suspend fun getSession(): UserSessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: UserSessionEntity)

    @Query("DELETE FROM user_sessions")
    suspend fun clearSession()
}

@Dao
interface RoomDao {
    @Query("SELECT * FROM rooms ORDER BY isPinned DESC, lastTimestamp DESC")
    fun getAllRooms(): Flow<List<RoomEntity>>

    @Query("SELECT * FROM rooms WHERE roomType IN ('DIRECT', 'GROUP') ORDER BY isPinned DESC, lastTimestamp DESC")
    fun getChatsAndGroups(): Flow<List<RoomEntity>>

    @Query("SELECT * FROM rooms WHERE roomType = 'INVITE' ORDER BY lastTimestamp DESC")
    fun getInvites(): Flow<List<RoomEntity>>

    @Query("SELECT * FROM rooms WHERE roomType = 'CHANNEL' ORDER BY lastTimestamp DESC")
    fun getChannels(): Flow<List<RoomEntity>>

    @Query("SELECT * FROM rooms WHERE roomType = 'COMMUNITY' OR parentSpaceId IS NOT NULL ORDER BY name ASC")
    fun getCommunities(): Flow<List<RoomEntity>>

    @Query("SELECT * FROM rooms WHERE roomId = :roomId LIMIT 1")
    fun getRoomById(roomId: String): Flow<RoomEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoom(room: RoomEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRooms(rooms: List<RoomEntity>)

    @Update
    suspend fun updateRoom(room: RoomEntity)

    @Query("UPDATE rooms SET lastMessage = :lastMessage, lastTimestamp = :timestamp WHERE roomId = :roomId")
    suspend fun updateLastMessage(roomId: String, lastMessage: String, timestamp: Long)

    @Query("UPDATE rooms SET unreadCount = 0 WHERE roomId = :roomId")
    suspend fun markRoomAsRead(roomId: String)

    @Query("DELETE FROM rooms WHERE roomId = :roomId")
    suspend fun deleteRoom(roomId: String)

    @Query("DELETE FROM rooms")
    suspend fun clearAllRooms()

    @Query("DELETE FROM rooms WHERE roomId IN ('!matrix_devs:matrix.org', '!carlos_direct:matrix.org', '!sofia_direct:kde.org', '!tech_channel:matrix.org', '!space_comunidad_hispana:matrix.org', '!sub_avisos:matrix.org', '!sub_general:matrix.org')")
    suspend fun deleteMockRooms()
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE roomId = :roomId ORDER BY timestamp ASC")
    fun getMessagesForRoom(roomId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE roomId = :roomId ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestMessage(roomId: String): MessageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<MessageEntity>)

    @Query("UPDATE messages SET status = :status WHERE id = :id")
    suspend fun updateMessageStatus(id: String, status: String)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteMessage(id: String)

    @Query("DELETE FROM messages")
    suspend fun clearAllMessages()

    @Query("DELETE FROM messages WHERE id IN ('msg_1', 'msg_2', 'msg_3', 'grp_msg_1', 'grp_msg_2')")
    suspend fun deleteMockMessages()
}

@Dao
interface StoryDao {
    @Query("SELECT * FROM stories WHERE expiresAt > :currentTime ORDER BY timestamp DESC")
    fun getActiveStories(currentTime: Long = System.currentTimeMillis()): Flow<List<StoryEntity>>

    @Query("SELECT * FROM stories WHERE isMine = 1 AND expiresAt > :currentTime ORDER BY timestamp DESC")
    fun getMyActiveStories(currentTime: Long = System.currentTimeMillis()): Flow<List<StoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: StoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStories(stories: List<StoryEntity>)

    @Query("UPDATE stories SET isViewed = 1, viewsCount = viewsCount + 1 WHERE id = :storyId")
    suspend fun markStoryViewed(storyId: String)

    @Query("DELETE FROM stories WHERE expiresAt <= :currentTime")
    suspend fun cleanExpiredStories(currentTime: Long = System.currentTimeMillis())

    @Query("DELETE FROM stories")
    suspend fun clearAllStories()

    @Query("DELETE FROM stories WHERE id IN ('story_carlos', 'story_sofia', 'story_david')")
    suspend fun deleteMockStories()
}

@Dao
interface ContactDao {
    @Query("SELECT * FROM contacts ORDER BY displayName ASC")
    fun getAllContacts(): Flow<List<ContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: ContactEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContacts(contacts: List<ContactEntity>)

    @Query("DELETE FROM contacts WHERE userId = :userId")
    suspend fun deleteContact(userId: String)

    @Query("DELETE FROM contacts")
    suspend fun clearAllContacts()

    @Query("DELETE FROM contacts WHERE userId IN ('@carlos.matrix:matrix.org', '@sofia.val:kde.org', '@david.dev:mozilla.modular.im', '@ana.music:envs.net', '@lucas:tchncs.de')")
    suspend fun deleteMockContacts()
}

@Dao
interface CallDao {
    @Query("SELECT * FROM calls ORDER BY timestamp DESC")
    fun getAllCalls(): Flow<List<CallEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCall(call: CallEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalls(calls: List<CallEntity>)

    @Query("DELETE FROM calls")
    suspend fun clearAllCalls()

    @Query("DELETE FROM calls WHERE contactName IN ('Carlos Méndez', 'Sofía Valenzuela', 'David Tech')")
    suspend fun deleteMockCalls()
}
