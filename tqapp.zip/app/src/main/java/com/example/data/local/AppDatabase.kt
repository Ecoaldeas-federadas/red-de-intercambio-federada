package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserSessionEntity::class,
        RoomEntity::class,
        MessageEntity::class,
        StoryEntity::class,
        ContactEntity::class,
        CallEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userSessionDao(): UserSessionDao
    abstract fun roomDao(): RoomDao
    abstract fun messageDao(): MessageDao
    abstract fun storyDao(): StoryDao
    abstract fun contactDao(): ContactDao
    abstract fun callDao(): CallDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "whatsapp_matrix.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    suspend fun clearAllData() {
        roomDao().clearAllRooms()
        messageDao().clearAllMessages()
        storyDao().clearAllStories()
        contactDao().clearAllContacts()
        callDao().clearAllCalls()
    }

    suspend fun deleteMockData() {
        roomDao().deleteMockRooms()
        messageDao().deleteMockMessages()
        storyDao().deleteMockStories()
        contactDao().deleteMockContacts()
        callDao().deleteMockCalls()
    }

    suspend fun prepopulateInitialData() {
        val now = System.currentTimeMillis()
        val oneHour = 3600000L

        // Default Contacts
        val defaultContacts = listOf(
            ContactEntity(
                userId = "@carlos.matrix:matrix.org",
                displayName = "Carlos Méndez (Matrix)",
                statusMessage = "Conectado a la federación Matrix 🚀",
                lastSeen = "en línea"
            ),
            ContactEntity(
                userId = "@sofia.val:kde.org",
                displayName = "Sofía Valenzuela",
                statusMessage = "En una reunión / No disponible para llamadas",
                lastSeen = "hace 10 min"
            ),
            ContactEntity(
                userId = "@david.dev:mozilla.modular.im",
                displayName = "David Tech",
                statusMessage = "Desarrollando apps nativas Android Compose 📱",
                lastSeen = "en línea"
            ),
            ContactEntity(
                userId = "@ana.music:envs.net",
                displayName = "Ana Martínez",
                statusMessage = "La música es vida 🎵",
                lastSeen = "hoy a las 11:20"
            ),
            ContactEntity(
                userId = "@lucas:tchncs.de",
                displayName = "Lucas Silva",
                statusMessage = "¡Disponible!",
                lastSeen = "en línea"
            )
        )
        contactDao().insertContacts(defaultContacts)

        // Default Rooms (Chats, Groups, Channels, Communities)
        val defaultRooms = listOf(
            RoomEntity(
                roomId = "!matrix_devs:matrix.org",
                name = "Desarrolladores Matrix & Android",
                topic = "Comunidad oficial de desarrolladores móviles federados",
                roomType = "GROUP",
                lastMessage = "David: Ya integré el soporte para historias de 24 horas vía Matrix 🎉",
                lastTimestamp = now - (12 * 60 * 1000L),
                unreadCount = 2,
                isPinned = true
            ),
            RoomEntity(
                roomId = "!carlos_direct:matrix.org",
                name = "Carlos Méndez (Matrix)",
                topic = "Chat directo federado",
                roomType = "DIRECT",
                lastMessage = "Hola! ¿Probaste conectarte a tu propio homeserver?",
                lastTimestamp = now - (25 * 60 * 1000L),
                unreadCount = 1,
                isPinned = true,
                directUserId = "@carlos.matrix:matrix.org"
            ),
            RoomEntity(
                roomId = "!sofia_direct:kde.org",
                name = "Sofía Valenzuela",
                topic = "Chat directo federado",
                roomType = "DIRECT",
                lastMessage = "Listo, te envié los documentos del proyecto.",
                lastTimestamp = now - (2 * oneHour),
                unreadCount = 0,
                directUserId = "@sofia.val:kde.org"
            ),
            RoomEntity(
                roomId = "!tech_channel:matrix.org",
                name = "Novedades & Canales Tech Matrix",
                topic = "Canal oficial de noticias sobre servidores federados y actualizaciones",
                roomType = "CHANNEL",
                lastMessage = "Nueva versión de Synapse disponible con mejoras de latencia.",
                lastTimestamp = now - (4 * oneHour),
                unreadCount = 0
            ),
            RoomEntity(
                roomId = "!space_comunidad_hispana:matrix.org",
                name = "Comunidad Matrix Hispana",
                topic = "Espacio matriz para todos los usuarios de habla hispana",
                roomType = "COMMUNITY",
                lastMessage = "Bienvenidos a la nueva comunidad federada",
                lastTimestamp = now - (6 * oneHour),
                unreadCount = 0
            ),
            RoomEntity(
                roomId = "!sub_avisos:matrix.org",
                name = "📢 Avisos de la Comunidad",
                topic = "Canal de anuncios del espacio hispano",
                roomType = "GROUP",
                parentSpaceId = "!space_comunidad_hispana:matrix.org",
                lastMessage = "Aviso: Mantenimiento programado el fin de semana.",
                lastTimestamp = now - (10 * oneHour),
                unreadCount = 0
            ),
            RoomEntity(
                roomId = "!sub_general:matrix.org",
                name = "💬 Charla General Hispana",
                topic = "Grupo general del espacio hispano",
                roomType = "GROUP",
                parentSpaceId = "!space_comunidad_hispana:matrix.org",
                lastMessage = "Lucas: Buenas tardes a todos desde España!",
                lastTimestamp = now - (1 * oneHour),
                unreadCount = 0
            )
        )
        roomDao().insertRooms(defaultRooms)

        // Default Messages for Carlos
        val defaultCarlosMessages = listOf(
            MessageEntity(
                id = "msg_1",
                roomId = "!carlos_direct:matrix.org",
                senderId = "@carlos.matrix:matrix.org",
                senderName = "Carlos Méndez",
                content = "¡Hola! Bienvenido a tu TqApp federado con Matrix 🚀",
                timestamp = now - (45 * 60 * 1000L),
                status = "READ",
                isOutgoing = false
            ),
            MessageEntity(
                id = "msg_2",
                roomId = "!carlos_direct:matrix.org",
                senderId = "@me",
                senderName = "Yo",
                content = "¡Qué genial! Tiene exactamente la misma interfaz fluida pero descentralizado con Matrix.",
                timestamp = now - (35 * 60 * 1000L),
                status = "READ",
                isOutgoing = true
            ),
            MessageEntity(
                id = "msg_3",
                roomId = "!carlos_direct:matrix.org",
                senderId = "@carlos.matrix:matrix.org",
                senderName = "Carlos Méndez",
                content = "Hola! ¿Probaste conectarte a tu propio homeserver?",
                timestamp = now - (25 * 60 * 1000L),
                status = "READ",
                isOutgoing = false
            )
        )
        messageDao().insertMessages(defaultCarlosMessages)

        // Default Messages for Group
        val defaultGroupMessages = listOf(
            MessageEntity(
                id = "grp_msg_1",
                roomId = "!matrix_devs:matrix.org",
                senderId = "@sofia.val:kde.org",
                senderName = "Sofía Valenzuela",
                content = "¿Alguien ha probado los canales y comunidades en Matrix Spaces?",
                timestamp = now - (30 * 60 * 1000L),
                status = "READ",
                isOutgoing = false
            ),
            MessageEntity(
                id = "grp_msg_2",
                roomId = "!matrix_devs:matrix.org",
                senderId = "@david.dev:mozilla.modular.im",
                senderName = "David Tech",
                content = "David: Ya integré el soporte para historias de 24 horas vía Matrix 🎉",
                timestamp = now - (12 * 60 * 1000L),
                status = "READ",
                isOutgoing = false
            )
        )
        messageDao().insertMessages(defaultGroupMessages)

        // Default 24-hour Stories (Estados de 24 horas)
        val defaultStories = listOf(
            StoryEntity(
                id = "story_carlos",
                userId = "@carlos.matrix:matrix.org",
                userName = "Carlos Méndez",
                content = "¡Probando el nuevo TqApp federado! Privacidad total y código libre 🛡️✨",
                backgroundColorHex = "#075E54",
                timestamp = now - (2 * oneHour),
                expiresAt = now + (22 * oneHour),
                isViewed = false,
                viewsCount = 14,
                isMine = false
            ),
            StoryEntity(
                id = "story_sofia",
                userId = "@sofia.val:kde.org",
                userName = "Sofía Valenzuela",
                content = "Atardecer hermoso terminando la semana de código 🌅☕",
                backgroundColorHex = "#792138",
                timestamp = now - (5 * oneHour),
                expiresAt = now + (19 * oneHour),
                isViewed = false,
                viewsCount = 28,
                isMine = false
            ),
            StoryEntity(
                id = "story_david",
                userId = "@david.dev:mozilla.modular.im",
                userName = "David Tech",
                content = "Configurando un nuevo servidor Synapse Matrix en Kubernetes 💻⚡",
                backgroundColorHex = "#1EBEA5",
                timestamp = now - (8 * oneHour),
                expiresAt = now + (16 * oneHour),
                isViewed = true,
                viewsCount = 42,
                isMine = false
            )
        )
        storyDao().insertStories(defaultStories)

        // Default Calls
        val defaultCalls = listOf(
            CallEntity(
                contactName = "Carlos Méndez",
                callType = "VOICE",
                direction = "INCOMING",
                timestamp = now - (3 * oneHour),
                durationSeconds = 145
            ),
            CallEntity(
                contactName = "Sofía Valenzuela",
                callType = "VIDEO",
                direction = "OUTGOING",
                timestamp = now - (22 * oneHour),
                durationSeconds = 310
            ),
            CallEntity(
                contactName = "David Tech",
                callType = "VOICE",
                direction = "MISSED",
                timestamp = now - (30 * oneHour),
                durationSeconds = 0
            )
        )
        callDao().insertCalls(defaultCalls)
    }
}
