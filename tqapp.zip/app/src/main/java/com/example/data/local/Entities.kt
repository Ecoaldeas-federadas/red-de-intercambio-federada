package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_sessions")
data class UserSessionEntity(
    @PrimaryKey val id: Int = 1,
    val userId: String,
    val homeserverUrl: String,
    val accessToken: String,
    val deviceId: String? = null,
    val displayName: String,
    val avatarUrl: String? = null,
    val isLoggedIn: Boolean = true,
    val isDemoMode: Boolean = false
)

@Entity(tableName = "rooms")
data class RoomEntity(
    @PrimaryKey val roomId: String,
    val name: String,
    val topic: String = "",
    val avatarUrl: String? = null,
    val roomType: String = "DIRECT", // "DIRECT", "GROUP", "CHANNEL", "COMMUNITY"
    val lastMessage: String = "",
    val lastTimestamp: Long = System.currentTimeMillis(),
    val unreadCount: Int = 0,
    val isPinned: Boolean = false,
    val isMuted: Boolean = false,
    val parentSpaceId: String? = null,
    val directUserId: String? = null
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val roomId: String,
    val senderId: String,
    val senderName: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "READ", // "SENDING", "SENT", "DELIVERED", "READ"
    val isOutgoing: Boolean = false,
    val messageType: String = "TEXT", // "TEXT", "IMAGE", "AUDIO", "DOCUMENT", "SYSTEM"
    val mediaUrl: String? = null,
    val mediaDuration: String? = null
)

@Entity(tableName = "stories")
data class StoryEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val userName: String,
    val userAvatar: String? = null,
    val content: String,
    val mediaUrl: String? = null,
    val backgroundColorHex: String = "#075E54",
    val timestamp: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 86400000L, // 24 hours
    val isViewed: Boolean = false,
    val viewsCount: Int = 0,
    val isMine: Boolean = false
)

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val userId: String,
    val displayName: String,
    val avatarUrl: String? = null,
    val statusMessage: String = "¡Hola! Estoy usando TqApp.",
    val lastSeen: String = "en línea"
)

@Entity(tableName = "calls")
data class CallEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contactName: String,
    val contactAvatar: String? = null,
    val callType: String = "VOICE", // "VOICE", "VIDEO"
    val direction: String = "INCOMING", // "INCOMING", "OUTGOING", "MISSED"
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0
)
