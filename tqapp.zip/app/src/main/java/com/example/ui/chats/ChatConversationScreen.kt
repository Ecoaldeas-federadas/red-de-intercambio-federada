package com.example.ui.chats

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MessageEntity
import com.example.data.local.RoomEntity
import com.example.ui.components.WhatsAppAvatar
import com.example.ui.components.WhatsAppChatDoodleCanvas
import com.example.ui.components.WhatsAppTicks
import com.example.ui.theme.WhatsAppBadgeGreen
import com.example.ui.theme.WhatsAppBubbleIncomingDark
import com.example.ui.theme.WhatsAppChatBgDark
import com.example.ui.theme.WhatsAppChatBgLight
import com.example.ui.theme.WhatsAppGreenBubbleDark
import com.example.ui.theme.WhatsAppGreenLight
import com.example.ui.theme.WhatsAppGreenPrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatConversationScreen(
    room: RoomEntity?,
    messages: List<MessageEntity>,
    onBack: () -> Unit,
    onSendMessage: (String) -> Unit,
    onStartCall: (String, Boolean) -> Unit
) {
    var messageText by remember { mutableStateOf("") }
    var showAttachmentSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val listState = rememberLazyListState()

    val isDark = isSystemInDarkTheme()
    val bgColor = if (isDark) WhatsAppChatBgDark else WhatsAppChatBgLight

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .imePadding()
    ) {
        // WhatsApp Chat Top Bar
        TopAppBar(
            navigationIcon = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onBack() }
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Atrás",
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    WhatsAppAvatar(
                        name = room?.name ?: "Sala",
                        size = 36.dp
                    )
                }
            },
            title = {
                Column(
                    modifier = Modifier
                        .clickable { }
                        .padding(start = 6.dp)
                ) {
                    Text(
                        text = room?.name ?: "Chat Matrix",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (room?.roomType == "GROUP") "grupo federado Matrix" else "en línea",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }
            },
            actions = {
                IconButton(
                    onClick = { onStartCall(room?.name ?: "Contacto", true) },
                    modifier = Modifier.testTag("chat_video_call")
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = "Videollamada",
                        tint = Color.White
                    )
                }
                IconButton(
                    onClick = { onStartCall(room?.name ?: "Contacto", false) },
                    modifier = Modifier.testTag("chat_voice_call")
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Llamada de voz",
                        tint = Color.White
                    )
                }
                IconButton(
                    onClick = { },
                    modifier = Modifier.testTag("chat_menu")
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Opciones",
                        tint = Color.White
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = WhatsAppGreenPrimary,
                titleContentColor = Color.White,
                actionIconContentColor = Color.White
            )
        )

        // Chat Body with WhatsApp Doodle Wallpaper
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(bgColor)
        ) {
            WhatsAppChatDoodleCanvas()

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Encryption Pill Notice (WhatsApp standard)
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDark) Color(0xFF182229) else Color(0xFFFFF3C4),
                            shadowElevation = 1.dp,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = if (isDark) Color(0xFFF7A235) else Color(0xFF856404),
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Los mensajes en esta sala están cifrados con el protocolo Matrix de extremo a extremo.",
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center,
                                    color = if (isDark) Color(0xFFE9EDEF) else Color(0xFF54656F),
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }

                // Messages list
                items(messages, key = { it.id }) { msg ->
                    ChatBubble(message = msg, isGroup = room?.roomType == "GROUP")
                }
            }
        }

        // WhatsApp Message Input Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Transparent)
                .padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Pill input
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDark) Color(0xFF1F2C34) else Color.White
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    IconButton(onClick = { }) {
                        Icon(
                            imageVector = Icons.Default.Mood,
                            contentDescription = "Emojis",
                            tint = Color(0xFF8696A0)
                        )
                    }

                    OutlinedTextField(
                        value = messageText,
                        onValueChange = { messageText = it },
                        placeholder = { Text("Mensaje", color = Color(0xFF8696A0), fontSize = 15.sp) },
                        textStyle = TextStyle(
                            color = if (isDark) Color(0xFFE9EDEF) else Color(0xFF111B21),
                            fontSize = 15.sp
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input_text"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = if (isDark) Color(0xFFE9EDEF) else Color(0xFF111B21),
                            unfocusedTextColor = if (isDark) Color(0xFFE9EDEF) else Color(0xFF111B21),
                            focusedPlaceholderColor = Color(0xFF8696A0),
                            unfocusedPlaceholderColor = Color(0xFF8696A0),
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            cursorColor = WhatsAppGreenPrimary
                        ),
                        maxLines = 4
                    )

                    IconButton(onClick = { showAttachmentSheet = true }) {
                        Icon(
                            imageVector = Icons.Default.AttachFile,
                            contentDescription = "Adjuntar",
                            tint = Color(0xFF8696A0)
                        )
                    }

                    if (messageText.isBlank()) {
                        IconButton(onClick = { }) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "Cámara",
                                tint = Color(0xFF8696A0)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Circular Green Action Button (Mic or Send)
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(WhatsAppBadgeGreen)
                    .clickable {
                        if (messageText.isNotBlank()) {
                            onSendMessage(messageText)
                            messageText = ""
                        }
                    }
                    .testTag("chat_send_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (messageText.isNotBlank()) Icons.AutoMirrored.Filled.Send else Icons.Default.Mic,
                    contentDescription = if (messageText.isNotBlank()) "Enviar" else "Grabar audio",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }

    // Attachment Modal Sheet (WhatsApp grid style)
    if (showAttachmentSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAttachmentSheet = false },
            sheetState = sheetState,
            containerColor = if (isDark) Color(0xFF1F2C34) else Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Text(
                    text = "Compartir en sala Matrix",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(bottom = 20.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    AttachmentOption(
                        icon = Icons.Default.Description,
                        label = "Documento",
                        color = Color(0xFF7F66FF),
                        onClick = {
                            onSendMessage("📄 Documento compartido: matrix_spec_v1.11.pdf")
                            showAttachmentSheet = false
                        }
                    )
                    AttachmentOption(
                        icon = Icons.Default.CameraAlt,
                        label = "Cámara",
                        color = Color(0xFFD3396D),
                        onClick = {
                            onSendMessage("📷 Foto tomada con la cámara")
                            showAttachmentSheet = false
                        }
                    )
                    AttachmentOption(
                        icon = Icons.Default.Image,
                        label = "Galería",
                        color = Color(0xFFAC44CF),
                        onClick = {
                            onSendMessage("🖼️ Imagen de la galería")
                            showAttachmentSheet = false
                        }
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    AttachmentOption(
                        icon = Icons.Default.Headphones,
                        label = "Audio",
                        color = Color(0xFFE95950),
                        onClick = {
                            onSendMessage("🎵 Nota de audio Matrix (0:18)")
                            showAttachmentSheet = false
                        }
                    )
                    AttachmentOption(
                        icon = Icons.Default.Poll,
                        label = "Encuesta",
                        color = Color(0xFF00A884),
                        onClick = {
                            onSendMessage("📊 Encuesta: ¿Qué homeserver Matrix prefieres?")
                            showAttachmentSheet = false
                        }
                    )
                    AttachmentOption(
                        icon = Icons.Default.Person,
                        label = "Contacto",
                        color = Color(0xFF007BFC),
                        onClick = {
                            onSendMessage("👤 Contacto: @soporte:matrix.org")
                            showAttachmentSheet = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun AttachmentOption(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = Color.White)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun ChatBubble(
    message: MessageEntity,
    isGroup: Boolean = false
) {
    val isDark = isSystemInDarkTheme()
    val isOutgoing = message.isOutgoing

    val timeFormatter = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val formattedTime = remember(message.timestamp) { timeFormatter.format(Date(message.timestamp)) }

    val bubbleColor = when {
        isOutgoing -> if (isDark) WhatsAppGreenBubbleDark else WhatsAppGreenLight
        else -> if (isDark) WhatsAppBubbleIncomingDark else Color.White
    }

    val alignment = if (isOutgoing) Alignment.CenterEnd else Alignment.CenterStart
    val shape = if (isOutgoing) {
        RoundedCornerShape(12.dp, 2.dp, 12.dp, 12.dp)
    } else {
        RoundedCornerShape(2.dp, 12.dp, 12.dp, 12.dp)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                start = if (isOutgoing) 48.dp else 0.dp,
                end = if (isOutgoing) 0.dp else 48.dp
            ),
        contentAlignment = alignment
    ) {
        Surface(
            shape = shape,
            color = bubbleColor,
            shadowElevation = 1.dp
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                // Sender name in Group chats
                if (!isOutgoing && isGroup) {
                    Text(
                        text = message.senderName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color(0xFF1E88E5),
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }

                // Message Text
                Text(
                    text = message.content,
                    fontSize = 15.sp,
                    color = if (isDark) Color(0xFFE9EDEF) else Color(0xFF111B21),
                    lineHeight = 20.sp
                )

                // Timestamp and check ticks
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formattedTime,
                        fontSize = 11.sp,
                        color = Color(0xFF8696A0),
                        modifier = Modifier.padding(end = 4.dp, top = 2.dp)
                    )
                    if (isOutgoing) {
                        WhatsAppTicks(status = message.status)
                    }
                }
            }
        }
    }
}
