package com.example.ui.main

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.ContactEntity
import com.example.ui.WhatsAppMatrixViewModel
import com.example.ui.calls.ActiveCallScreen
import com.example.ui.calls.CallsTab
import com.example.ui.chats.ChatConversationScreen
import com.example.ui.chats.ChatsListTab
import com.example.ui.communities.CommunitiesTab
import com.example.ui.components.WhatsAppBottomNavigation
import com.example.ui.components.WhatsAppTab
import com.example.ui.components.WhatsAppTopBar
import com.example.ui.contacts.NewChatDialog
import com.example.ui.settings.ServerSettingsDialog
import com.example.ui.stories.FullScreenStoryViewer
import com.example.ui.stories.UpdatesTab
import kotlinx.coroutines.launch

@Composable
fun MainScreen(viewModel: WhatsAppMatrixViewModel) {
    var currentTab by remember { mutableStateOf(WhatsAppTab.CHATS) }
    var showNewChatDialog by remember { mutableStateOf(false) }
    var showServerSettings by remember { mutableStateOf(false) }

    val session by viewModel.sessionState.collectAsStateWithLifecycle()
    val chats by viewModel.chatsState.collectAsStateWithLifecycle()
    val channels by viewModel.channelsState.collectAsStateWithLifecycle()
    val communities by viewModel.communitiesState.collectAsStateWithLifecycle()
    val contacts by viewModel.contactsState.collectAsStateWithLifecycle()
    val activeStories by viewModel.activeStoriesState.collectAsStateWithLifecycle()
    val myStories by viewModel.myStoriesState.collectAsStateWithLifecycle()
    val calls by viewModel.callsState.collectAsStateWithLifecycle()
    val isSyncing by viewModel.isSyncing.collectAsStateWithLifecycle()
    val invites by viewModel.invitesState.collectAsStateWithLifecycle()

    val currentRoomId by viewModel.currentRoomId.collectAsStateWithLifecycle()
    val currentRoom by viewModel.currentRoom.collectAsStateWithLifecycle()
    val currentMessages by viewModel.currentMessages.collectAsStateWithLifecycle()

    val activeCall by viewModel.activeCall.collectAsStateWithLifecycle()
    val viewingStory by viewModel.viewingStory.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val unreadTotal = remember(chats) { chats.sumOf { it.unreadCount } }

    // If chat is open, handle hardware back button to exit chat
    BackHandler(enabled = currentRoomId != null) {
        viewModel.closeChat()
    }

    if (currentRoomId != null) {
        ChatConversationScreen(
            room = currentRoom,
            messages = currentMessages,
            onBack = { viewModel.closeChat() },
            onSendMessage = { text -> viewModel.sendMessage(text) },
            onStartCall = { contactName, isVideo ->
                viewModel.startCall(contactName, isVideo)
            }
        )
    } else {
        Scaffold(
            topBar = {
                WhatsAppTopBar(
                    title = "TqApp",
                    serverName = session?.homeserverUrl?.removePrefix("https://")?.removePrefix("http://") ?: "matrix.org",
                    onCameraClick = {
                        scope.launch {
                            snackbarHostState.showSnackbar("Cámara Matrix lista para fotos y estados")
                        }
                    },
                    onSearchClick = {
                        showNewChatDialog = true
                    },
                    onNewGroupClick = {
                        showNewChatDialog = true
                    },
                    onNewCommunityClick = {
                        currentTab = WhatsAppTab.COMUNIDADES
                    },
                    onSyncClick = {
                        viewModel.refreshSync()
                        scope.launch {
                            snackbarHostState.showSnackbar("Sincronizando con Matrix...")
                        }
                    },
                    onServerSettingsClick = {
                        showServerSettings = true
                    },
                    onLogoutClick = {
                        viewModel.logout()
                    }
                )
            },
            bottomBar = {
                WhatsAppBottomNavigation(
                    selectedTab = currentTab,
                    unreadChatsCount = unreadTotal,
                    hasNewStories = activeStories.any { !it.isViewed && !it.isMine },
                    onTabSelected = { currentTab = it }
                )
            },
            snackbarHost = { SnackbarHost(snackbarHostState) }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (currentTab) {
                    WhatsAppTab.CHATS -> {
                        ChatsListTab(
                            rooms = chats,
                            invites = invites,
                            stories = activeStories,
                            isSyncing = isSyncing,
                            onRefreshSync = { viewModel.refreshSync() },
                            onAcceptInvite = { roomId -> viewModel.acceptInvite(roomId) },
                            onRejectInvite = { roomId -> viewModel.rejectInvite(roomId) },
                            onAcceptAllInvites = { viewModel.acceptAllInvites() },
                            onRoomClick = { roomId -> viewModel.openChat(roomId) },
                            onStoryClick = { story -> viewModel.openStory(story) },
                            onNewChatClick = { showNewChatDialog = true }
                        )
                    }

                    WhatsAppTab.NOVEDADES -> {
                        UpdatesTab(
                            stories = activeStories,
                            myStories = myStories,
                            channels = channels,
                            onOpenStory = { story -> viewModel.openStory(story) },
                            onPostStory = { text, colorHex -> viewModel.postStory(text, colorHex) },
                            onChannelClick = { roomId -> viewModel.openChat(roomId) }
                        )
                    }

                    WhatsAppTab.COMUNIDADES -> {
                        CommunitiesTab(
                            communities = communities,
                            onRoomClick = { roomId -> viewModel.openChat(roomId) },
                            onCreateCommunity = { name, topic ->
                                viewModel.createCommunity(name, topic)
                            }
                        )
                    }

                    WhatsAppTab.LLAMADAS -> {
                        CallsTab(
                            calls = calls,
                            onStartCall = { contactName, isVideo ->
                                viewModel.startCall(contactName, isVideo)
                            },
                            onNewCallClick = { showNewChatDialog = true }
                        )
                    }
                }
            }
        }
    }

    // New Chat / Select Contact Dialog
    if (showNewChatDialog) {
        NewChatDialog(
            contacts = contacts,
            onDismiss = { showNewChatDialog = false },
            onContactSelected = { contact: ContactEntity ->
                viewModel.createDirectChat(contact)
            },
            onNewGroupClick = {
                viewModel.createGroup("Nuevo Grupo Matrix", "Grupo federado", emptyList())
            },
            onNewCommunityClick = {
                currentTab = WhatsAppTab.COMUNIDADES
            },
            onDirectMatrixIdChat = { mxid ->
                val tempContact = ContactEntity(
                    userId = mxid,
                    displayName = mxid.removePrefix("@").substringBefore(":")
                )
                viewModel.createDirectChat(tempContact)
            }
        )
    }

    // Server Settings Dialog
    if (showServerSettings) {
        ServerSettingsDialog(
            session = session,
            onDismiss = { showServerSettings = false },
            onLogout = { viewModel.logout() },
            onUpdateDisplayName = { newName -> viewModel.updateDisplayName(newName) },
            onUpdateAvatarUrl = { newAvatar -> viewModel.updateAvatarUrl(newAvatar) }
        )
    }

    // Active Full-screen Story Viewer
    viewingStory?.let { story ->
        FullScreenStoryViewer(
            story = story,
            onClose = { viewModel.closeStory() },
            onReply = { reply ->
                scope.launch {
                    snackbarHostState.showSnackbar("Respuesta enviada a ${story.userName}")
                }
            }
        )
    }

    // Active Call Screen Modal
    activeCall?.let { call ->
        ActiveCallScreen(
            callInfo = call,
            onEndCall = { viewModel.endCall() },
            onToggleMute = { viewModel.toggleMuteCall() },
            onToggleSpeaker = { viewModel.toggleSpeakerCall() }
        )
    }
}
