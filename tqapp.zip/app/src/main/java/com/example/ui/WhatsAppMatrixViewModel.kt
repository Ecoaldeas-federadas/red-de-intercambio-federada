package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.CallEntity
import com.example.data.local.ContactEntity
import com.example.data.local.MessageEntity
import com.example.data.local.RoomEntity
import com.example.data.local.StoryEntity
import com.example.data.local.UserSessionEntity
import com.example.data.matrix.MatrixServer
import com.example.data.matrix.MatrixServersConfig
import com.example.data.repository.AuthResult
import com.example.data.repository.MatrixRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ActiveCallInfo(
    val contactName: String,
    val isVideo: Boolean,
    val durationSeconds: Int = 0,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = false
)

class WhatsAppMatrixViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    val repository = MatrixRepository(database)

    // Proposed homeservers list (allows adding custom servers at runtime)
    private val _serversList = MutableStateFlow(MatrixServersConfig.PROPOSED_SERVERS)
    val serversList: StateFlow<List<MatrixServer>> = _serversList.asStateFlow()

    private val _selectedServer = MutableStateFlow(MatrixServersConfig.getDefaultServer())
    val selectedServer: StateFlow<MatrixServer> = _selectedServer.asStateFlow()

    val isSyncing: StateFlow<Boolean> = repository.isSyncing

    private val _authLoading = MutableStateFlow(false)
    val authLoading: StateFlow<Boolean> = _authLoading.asStateFlow()

    init {
        // When ViewModel starts, if a real session exists, purge mock data and sync real Matrix rooms
        viewModelScope.launch {
            val session = repository.getCurrentSession()
            if (session != null && !session.isDemoMode) {
                database.deleteMockData()
                repository.syncWithMatrix(timeout = 0)
            }
        }

        // Background continuous Matrix sync loop
        viewModelScope.launch {
            while (true) {
                delay(12000)
                val session = repository.getCurrentSession()
                if (session != null && !session.isDemoMode) {
                    try {
                        repository.syncWithMatrix(timeout = 8000)
                    } catch (_: Exception) {}
                }
            }
        }
    }

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    val sessionState: StateFlow<UserSessionEntity?> = repository.sessionFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val chatsState: StateFlow<List<RoomEntity>> = repository.roomsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val invitesState: StateFlow<List<RoomEntity>> = repository.invitesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val channelsState: StateFlow<List<RoomEntity>> = repository.channelsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val communitiesState: StateFlow<List<RoomEntity>> = repository.communitiesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val contactsState: StateFlow<List<ContactEntity>> = repository.contactsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val activeStoriesState: StateFlow<List<StoryEntity>> = repository.activeStoriesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val myStoriesState: StateFlow<List<StoryEntity>> = repository.myStoriesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val callsState: StateFlow<List<CallEntity>> = repository.callsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Current open chat conversation
    private val _currentRoomId = MutableStateFlow<String?>(null)
    val currentRoomId: StateFlow<String?> = _currentRoomId.asStateFlow()

    val currentRoom: StateFlow<RoomEntity?> = _currentRoomId.flatMapLatest { id ->
        if (id != null) repository.getRoom(id) else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentMessages: StateFlow<List<MessageEntity>> = _currentRoomId.flatMapLatest { id ->
        if (id != null) repository.getMessagesForRoom(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Simulated Call
    private val _activeCall = MutableStateFlow<ActiveCallInfo?>(null)
    val activeCall: StateFlow<ActiveCallInfo?> = _activeCall.asStateFlow()
    private var callTimerJob: Job? = null

    // Story viewer dialog
    private val _viewingStory = MutableStateFlow<StoryEntity?>(null)
    val viewingStory: StateFlow<StoryEntity?> = _viewingStory.asStateFlow()

    // Interactive Authentication (reCAPTCHA) challenge state
    private val _recaptchaChallenge = MutableStateFlow<RecaptchaChallengeState?>(null)
    val recaptchaChallenge: StateFlow<RecaptchaChallengeState?> = _recaptchaChallenge.asStateFlow()

    fun selectServer(server: MatrixServer) {
        _selectedServer.value = server
        _authError.value = null
    }

    fun addCustomServer(name: String, url: String) {
        val cleanUrl = MatrixServersConfig.cleanUrl(url)
        val customServer = MatrixServer(
            id = "custom_" + System.currentTimeMillis(),
            name = name.ifBlank { cleanUrl.removePrefix("https://").removePrefix("http://") },
            url = cleanUrl,
            description = "Servidor personalizado",
            isDefault = false,
            allowsPublicRegistration = true
        )
        _serversList.value = _serversList.value + customServer
        _selectedServer.value = customServer
    }

    fun clearAuthError() {
        _authError.value = null
    }

    fun login(username: String, password: String) {
        if (username.isBlank() || password.isBlank()) {
            _authError.value = "Por favor, introduce tu usuario y contraseña de Matrix"
            return
        }
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.loginWithMatrix(
                serverUrl = _selectedServer.value.url,
                usernameInput = username,
                password = password
            )
            _authLoading.value = false
            if (result is AuthResult.Error) {
                _authError.value = result.message
            }
        }
    }

    fun register(username: String, password: String) {
        if (username.isBlank() || password.isBlank()) {
            _authError.value = "Por favor, completa los campos requeridos para el registro"
            return
        }
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.registerWithMatrix(
                serverUrl = _selectedServer.value.url,
                usernameInput = username,
                password = password
            )
            _authLoading.value = false
            when (result) {
                is AuthResult.Error -> {
                    _authError.value = result.message
                }
                is AuthResult.RequiresRecaptcha -> {
                    _recaptchaChallenge.value = RecaptchaChallengeState(
                        session = result.session,
                        publicKey = result.publicKey,
                        serverUrl = result.serverUrl,
                        username = result.username,
                        password = result.password
                    )
                }
                is AuthResult.Success -> {
                    _recaptchaChallenge.value = null
                }
            }
        }
    }

    fun completeRecaptcha(token: String) {
        val challenge = _recaptchaChallenge.value ?: return
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.completeRecaptchaRegistration(
                serverUrl = challenge.serverUrl,
                username = challenge.username,
                password = challenge.password,
                session = challenge.session,
                recaptchaToken = token
            )
            _authLoading.value = false
            when (result) {
                is AuthResult.Error -> {
                    _authError.value = result.message
                }
                is AuthResult.RequiresRecaptcha -> {
                    // Retry with updated session if needed
                }
                is AuthResult.Success -> {
                    _recaptchaChallenge.value = null
                }
            }
        }
    }

    fun dismissRecaptcha() {
        _recaptchaChallenge.value = null
    }

    fun loginWithToken(token: String) {
        if (token.isBlank()) return
        viewModelScope.launch {
            _authLoading.value = true
            _authError.value = null
            val result = repository.loginWithMatrixToken(
                serverUrl = _selectedServer.value.url,
                token = token
            )
            _authLoading.value = false
            when (result) {
                is AuthResult.Error -> {
                    _authError.value = result.message
                }
                is AuthResult.Success -> {
                    _authError.value = null
                    _recaptchaChallenge.value = null
                }
                is AuthResult.RequiresRecaptcha -> {
                    _authError.value = "Verificación requerida"
                }
            }
        }
    }

    fun loginAsDemo(username: String = "usuario_matrix") {
        viewModelScope.launch {
            _authLoading.value = true
            repository.loginAsQuickDemo(
                chosenServerUrl = _selectedServer.value.url,
                username = username
            )
            _authLoading.value = false
        }
    }

    fun logout() {
        viewModelScope.launch {
            _currentRoomId.value = null
            repository.logout()
        }
    }

    fun refreshSync() {
        viewModelScope.launch {
            repository.syncWithMatrix(timeout = 0)
        }
    }

    fun openChat(roomId: String) {
        _currentRoomId.value = roomId
        viewModelScope.launch {
            repository.markRoomAsRead(roomId)
            repository.fetchRoomHistory(roomId)
        }
    }

    fun closeChat() {
        _currentRoomId.value = null
    }

    fun sendMessage(text: String) {
        val roomId = _currentRoomId.value ?: return
        viewModelScope.launch {
            repository.sendMessage(roomId, text)
        }
    }

    fun createDirectChat(contact: ContactEntity) {
        viewModelScope.launch {
            val roomId = repository.createRoom(
                name = contact.displayName,
                topic = "Chat privado federado con ${contact.userId}",
                roomType = "DIRECT",
                isDirect = true,
                inviteUserId = contact.userId
            )
            openChat(roomId)
        }
    }

    fun createGroup(name: String, topic: String, members: List<String>) {
        viewModelScope.launch {
            val roomId = repository.createRoom(
                name = name,
                topic = topic,
                roomType = "GROUP",
                isDirect = false
            )
            openChat(roomId)
        }
    }

    fun createCommunity(name: String, topic: String) {
        viewModelScope.launch {
            repository.createRoom(
                name = name,
                topic = topic,
                roomType = "COMMUNITY"
            )
        }
    }

    fun postStory(text: String, colorHex: String) {
        viewModelScope.launch {
            repository.postStory(text, colorHex)
        }
    }

    fun openStory(story: StoryEntity) {
        _viewingStory.value = story
        viewModelScope.launch {
            repository.markStoryViewed(story.id)
        }
    }

    fun closeStory() {
        _viewingStory.value = null
    }

    fun startCall(contactName: String, isVideo: Boolean) {
        _activeCall.value = ActiveCallInfo(
            contactName = contactName,
            isVideo = isVideo,
            durationSeconds = 0
        )
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _activeCall.value = _activeCall.value?.let { current ->
                    current.copy(durationSeconds = current.durationSeconds + 1)
                }
            }
        }
    }

    fun endCall() {
        val call = _activeCall.value
        callTimerJob?.cancel()
        callTimerJob = null
        if (call != null) {
            viewModelScope.launch {
                repository.registerCall(
                    contactName = call.contactName,
                    callType = if (call.isVideo) "VIDEO" else "VOICE",
                    direction = "OUTGOING",
                    duration = call.durationSeconds
                )
            }
        }
        _activeCall.value = null
    }

    fun toggleMuteCall() {
        _activeCall.value = _activeCall.value?.let { it.copy(isMuted = !it.isMuted) }
    }

    fun toggleSpeakerCall() {
        _activeCall.value = _activeCall.value?.let { it.copy(isSpeakerOn = !it.isSpeakerOn) }
    }

    fun acceptInvite(roomId: String) {
        viewModelScope.launch {
            repository.acceptInvite(roomId)
        }
    }

    fun rejectInvite(roomId: String) {
        viewModelScope.launch {
            repository.rejectInvite(roomId)
        }
    }

    fun acceptAllInvites() {
        viewModelScope.launch {
            repository.acceptAllInvites()
        }
    }

    fun updateDisplayName(newName: String) {
        viewModelScope.launch {
            repository.updateDisplayName(newName)
        }
    }

    fun updateAvatarUrl(newAvatarUrl: String) {
        viewModelScope.launch {
            repository.updateAvatarUrl(newAvatarUrl)
        }
    }
}

data class RecaptchaChallengeState(
    val session: String,
    val publicKey: String,
    val serverUrl: String,
    val username: String,
    val password: String
)
